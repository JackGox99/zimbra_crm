"""
Backend mínimo — Entrega Inicial Sesión 2
Sistema Transaccional Zimbra CRM — UNIMINUTO

Demuestra la conexión Python ↔ MySQL del proyecto y expone endpoints
básicos documentados automáticamente en Swagger UI (FastAPI).

Equipo:
  Hayder Esteban Barrera Pérez
  Julian Mateo Artunduaga Gomez
  Valery Tatiana Pamplona Gómez

Docente: Ladi Paola Ballen Carrasco

Cómo correr:
    pip install -r requirements.txt
    cp .env.example .env             (y editar DB_PASSWORD)
    uvicorn main:app --reload

Luego abrir:
    http://127.0.0.1:8000/docs       Swagger UI
    http://127.0.0.1:8000/health     healthcheck simple
    http://127.0.0.1:8000/api/db/ping  prueba real de la conexión a MySQL
"""

import os
from pathlib import Path
from typing import Any

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import create_engine, text
from sqlalchemy.exc import OperationalError, SQLAlchemyError

# --- Variables de entorno --------------------------------------------------
load_dotenv(Path(__file__).resolve().parent / ".env")

DB_HOST = os.getenv("DB_HOST", "127.0.0.1")
DB_PORT = os.getenv("DB_PORT", "3306")
DB_USER = os.getenv("DB_USER", "root")
DB_PASSWORD = os.getenv("DB_PASSWORD", "")
DB_NAME = os.getenv("DB_NAME", "zimbra_crm")

DATABASE_URL = (
    f"mysql+pymysql://{DB_USER}:{DB_PASSWORD}"
    f"@{DB_HOST}:{DB_PORT}/{DB_NAME}?charset=utf8mb4"
)

# Engine SQLAlchemy con pre-ping para detectar conexiones caídas.
engine = create_engine(DATABASE_URL, pool_pre_ping=True, pool_recycle=3600)


# --- Aplicación FastAPI ----------------------------------------------------
app = FastAPI(
    title="Zimbra CRM — Backend Entrega Inicial",
    description=(
        "Backend mínimo en Python (FastAPI + SQLAlchemy + PyMySQL) que "
        "valida la conexión a la base de datos MySQL del proyecto Zimbra "
        "CRM y expone endpoints REST de solo lectura para confirmar que "
        "los datos cargados por el script `zimbra_crm.sql` son accesibles.\n\n"
        "**Equipo:** Hayder Esteban Barrera Pérez · "
        "Julian Mateo Artunduaga Gomez · Valery Tatiana Pamplona Gómez\n\n"
        "**Docente:** Ladi Paola Ballen Carrasco\n\n"
        "**Asignatura:** Sistemas Transaccionales de Bases de Datos — UNIMINUTO"
    ),
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


# --- Helpers ---------------------------------------------------------------
def _select(query: str, params: dict[str, Any] | None = None) -> list[dict[str, Any]]:
    """Ejecuta un SELECT parametrizado y devuelve una lista de diccionarios."""
    try:
        with engine.connect() as conn:
            result = conn.execute(text(query), params or {})
            return [dict(row._mapping) for row in result]
    except OperationalError as e:
        raise HTTPException(
            status_code=503,
            detail=f"No se pudo conectar a la base de datos: {e.orig}",
        )
    except SQLAlchemyError as e:
        raise HTTPException(
            status_code=500, detail=f"Error en la consulta: {e}"
        )


# --- Endpoints de salud / verificación de conexión -------------------------
@app.get("/health", tags=["Salud"], summary="Healthcheck de la API")
def health() -> dict[str, str]:
    """Verifica que la API esté arriba. No consulta la BD."""
    return {"status": "ok", "api": "zimbra_crm_entrega_inicial"}


@app.get("/api/db/ping", tags=["Salud"], summary="Probar la conexión a MySQL")
def db_ping() -> dict[str, Any]:
    """
    Ejecuta `SELECT 1` y `SELECT VERSION()` para confirmar que la
    base de datos está accesible y devolver la versión del servidor.
    """
    try:
        with engine.connect() as conn:
            ok = conn.execute(text("SELECT 1")).scalar()
            version = conn.execute(text("SELECT VERSION()")).scalar()
        return {
            "db_reachable": True,
            "select_1": ok,
            "mysql_version": version,
            "host": DB_HOST,
            "port": DB_PORT,
            "database": DB_NAME,
        }
    except OperationalError as e:
        raise HTTPException(
            status_code=503, detail=f"BD inaccesible: {e.orig}"
        )


@app.get(
    "/api/db/info",
    tags=["Salud"],
    summary="Tablas de la BD y conteo de registros por tabla",
)
def db_info() -> dict[str, Any]:
    """
    Lista las 9 tablas del esquema `zimbra_crm` y devuelve el conteo
    de filas en cada una. Sirve para validar que el script
    `zimbra_crm.sql` se ejecutó correctamente.
    """
    try:
        with engine.connect() as conn:
            tablas = [row[0] for row in conn.execute(text("SHOW TABLES"))]
            conteos: dict[str, int] = {}
            for t in tablas:
                # Backtick para que tablas con mayúsculas no rompan.
                conteos[t] = conn.execute(
                    text(f"SELECT COUNT(*) FROM `{t}`")
                ).scalar()
        return {"database": DB_NAME, "tables": tablas, "row_counts": conteos}
    except OperationalError as e:
        raise HTTPException(
            status_code=503, detail=f"BD inaccesible: {e.orig}"
        )


# --- Endpoints de lectura por tabla ----------------------------------------
# Solo lectura (GET). El objetivo de esta entrega inicial es DEMOSTRAR la
# conexión, no construir un CRUD completo. Cada endpoint devuelve los
# registros de su tabla limitados por `limit` (1..500, default 50).

LIMIT_DEFAULT = 50
LIMIT_MAX = 500


@app.get("/api/campanas", tags=["Datos"], summary="Listar campañas")
def listar_campanas(
    limit: int = Query(LIMIT_DEFAULT, ge=1, le=LIMIT_MAX)
) -> list[dict[str, Any]]:
    return _select(
        "SELECT * FROM CAMPANA ORDER BY id_campana LIMIT :lim",
        {"lim": limit},
    )


@app.get("/api/prospectos", tags=["Datos"], summary="Listar prospectos")
def listar_prospectos(
    limit: int = Query(LIMIT_DEFAULT, ge=1, le=LIMIT_MAX)
) -> list[dict[str, Any]]:
    return _select(
        "SELECT * FROM PROSPECTO ORDER BY id_prospecto LIMIT :lim",
        {"lim": limit},
    )


@app.get(
    "/api/interacciones", tags=["Datos"], summary="Listar interacciones de marketing"
)
def listar_interacciones(
    limit: int = Query(LIMIT_DEFAULT, ge=1, le=LIMIT_MAX)
) -> list[dict[str, Any]]:
    return _select(
        "SELECT * FROM INTERACCION_MARKETING ORDER BY fecha_interaccion DESC LIMIT :lim",
        {"lim": limit},
    )


@app.get("/api/plantillas", tags=["Datos"], summary="Listar plantillas de comunicación")
def listar_plantillas(
    limit: int = Query(LIMIT_DEFAULT, ge=1, le=LIMIT_MAX)
) -> list[dict[str, Any]]:
    return _select(
        "SELECT * FROM PLANTILLA_COMUNICACION ORDER BY id_plantilla LIMIT :lim",
        {"lim": limit},
    )


@app.get(
    "/api/comunicaciones",
    tags=["Datos"],
    summary="Listar comunicaciones enviadas",
)
def listar_comunicaciones(
    limit: int = Query(LIMIT_DEFAULT, ge=1, le=LIMIT_MAX)
) -> list[dict[str, Any]]:
    return _select(
        "SELECT * FROM COMUNICACION_ENVIADA ORDER BY fecha_envio DESC LIMIT :lim",
        {"lim": limit},
    )


@app.get("/api/propuestas", tags=["Datos"], summary="Listar propuestas comerciales")
def listar_propuestas(
    limit: int = Query(LIMIT_DEFAULT, ge=1, le=LIMIT_MAX)
) -> list[dict[str, Any]]:
    return _select(
        "SELECT * FROM PROPUESTA ORDER BY id_propuesta DESC LIMIT :lim",
        {"lim": limit},
    )


@app.get("/api/clientes", tags=["Datos"], summary="Listar clientes")
def listar_clientes(
    limit: int = Query(LIMIT_DEFAULT, ge=1, le=LIMIT_MAX)
) -> list[dict[str, Any]]:
    return _select(
        "SELECT * FROM CLIENTE ORDER BY id_cliente LIMIT :lim",
        {"lim": limit},
    )


@app.get("/api/ventas", tags=["Datos"], summary="Listar ventas")
def listar_ventas(
    limit: int = Query(LIMIT_DEFAULT, ge=1, le=LIMIT_MAX)
) -> list[dict[str, Any]]:
    return _select(
        "SELECT * FROM VENTA ORDER BY fecha_venta DESC LIMIT :lim",
        {"lim": limit},
    )


@app.get("/api/reportes", tags=["Datos"], summary="Listar reportes")
def listar_reportes(
    limit: int = Query(LIMIT_DEFAULT, ge=1, le=LIMIT_MAX)
) -> list[dict[str, Any]]:
    return _select(
        "SELECT * FROM REPORTE ORDER BY fecha_generacion DESC LIMIT :lim",
        {"lim": limit},
    )
