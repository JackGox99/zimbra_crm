# Backend mínimo — Entrega Inicial

Conexión inicial Python ↔ MySQL del proyecto **Zimbra CRM**.
Single file (`main.py`), FastAPI con Swagger UI nativo.

## Prerrequisitos

1. Python 3.11 o superior.
2. MySQL 8.0+ corriendo localmente.
3. La base de datos `zimbra_crm` creada por el script de la carpeta padre:

   ```bash
   mysql -u root -p < ../zimbra_crm.sql
   ```

## Instalación

```bash
cd entrega_inicial/backend
python3 -m venv .venv
source .venv/bin/activate          # en Windows: .venv\Scripts\activate
pip install --upgrade pip
pip install -r requirements.txt
cp .env.example .env               # editar DB_PASSWORD
```

## Ejecución

```bash
uvicorn main:app --reload
```

Salida esperada:
```
INFO:     Uvicorn running on http://127.0.0.1:8000
INFO:     Application startup complete.
```

## URLs útiles

| URL | Qué muestra |
|---|---|
| http://127.0.0.1:8000/docs | **Swagger UI** — todos los endpoints, probables desde el navegador |
| http://127.0.0.1:8000/redoc | Documentación alternativa (ReDoc) |
| http://127.0.0.1:8000/health | Confirma que la API responde |
| http://127.0.0.1:8000/api/db/ping | Confirma que MySQL responde y muestra su versión |
| http://127.0.0.1:8000/api/db/info | Lista las 9 tablas y conteo de filas por tabla |

## Endpoints expuestos

### Tag `Salud` (verificación de conexión)

| Método | URL | Descripción |
|---|---|---|
| GET | `/health` | Healthcheck simple (no toca la BD) |
| GET | `/api/db/ping` | `SELECT 1` + versión de MySQL |
| GET | `/api/db/info` | Lista tablas + conteo de filas |

### Tag `Datos` (lectura de cada tabla)

| Método | URL | Tabla |
|---|---|---|
| GET | `/api/campanas` | `CAMPANA` |
| GET | `/api/prospectos` | `PROSPECTO` |
| GET | `/api/interacciones` | `INTERACCION_MARKETING` |
| GET | `/api/plantillas` | `PLANTILLA_COMUNICACION` |
| GET | `/api/comunicaciones` | `COMUNICACION_ENVIADA` |
| GET | `/api/propuestas` | `PROPUESTA` |
| GET | `/api/clientes` | `CLIENTE` |
| GET | `/api/ventas` | `VENTA` |
| GET | `/api/reportes` | `REPORTE` |

Todos los endpoints `/api/<tabla>` aceptan el parámetro opcional
`?limit=N` (por defecto 50, máximo 500).

## Validación rápida desde la terminal

```bash
# Healthcheck
curl http://127.0.0.1:8000/health

# Conexión a la BD
curl http://127.0.0.1:8000/api/db/ping

# Conteo por tabla (debe mostrar 30+ en cada una)
curl http://127.0.0.1:8000/api/db/info

# Primer prospecto
curl 'http://127.0.0.1:8000/api/prospectos?limit=1'
```

## Stack técnico

| Componente | Versión |
|---|---|
| Python | 3.11+ |
| FastAPI | 0.115.6 |
| SQLAlchemy | 2.0.36 (modo *core*, sin ORM) |
| PyMySQL + cryptography | 1.1.1 + 44.0.0 |
| python-dotenv | 1.0.1 |
| Uvicorn | 0.34.0 |

## Troubleshooting

| Error | Causa probable | Solución |
|---|---|---|
| `Access denied for user 'root'@'localhost'` | Contraseña incorrecta en `.env` | Editar `DB_PASSWORD` |
| `Can't connect to MySQL server` | MySQL no está corriendo | `sudo systemctl start mysqld` |
| `Unknown database 'zimbra_crm'` | No se ejecutó el script SQL | `mysql -u root -p < ../zimbra_crm.sql` |
| `cryptography package is required` | Falta dependencia | `pip install cryptography` |
| Puerto 8000 ocupado | Otro proceso escucha | `uvicorn main:app --port 8080` |

---

**Equipo:** Hayder Esteban Barrera Pérez · Julian Mateo Artunduaga Gomez · Valery Tatiana Pamplona Gómez
**Docente:** Ladi Paola Ballen Carrasco
**Asignatura:** Sistemas Transaccionales de Bases de Datos — UNIMINUTO